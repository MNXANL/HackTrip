# HackTrip
Website developed for HackUPC Fall 2016. 

The aim of this site is to search for the best planes you can get just before and after any MLH-sanctioned hackathon, as long as its schedule is known.
For example, if you are from Barcelona and want to go to Junction 2016, you'll get some results for a trip that guarantees you won't miss a thing!

Developed by Aaron Jimenez, Miguel Moreno and Alex Viñas.